﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        private Logic textProcessor; // Экземпляр класса для обработки текста

        public Form1()
        {
            InitializeComponent();
            InitializeTextProcessor();

            LoadSavedText(); // Загрузка сохраненного текста при загрузке формы

            // Добавляем обработчик события KeyDown для всей формы
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;
        }

        private void InitializeTextProcessor()
        {
            textProcessor = new Logic();
        }

        private void LoadSavedText()
        {
            string savedText = Properties.Settings.Default.text;
            textBox1.Text = savedText; // Отображение сохраненного текста в textBox1
        }

        private void SaveText()
        {
            // Сохранение введенного текста в параметры настроек
            Properties.Settings.Default.text = textBox1.Text;
            Properties.Settings.Default.Save(); // Сохранение изменений
        }

        private void ProcessAndDisplayText()
        {
            string processedText = textProcessor.ProcessText(textBox1.Text);
            MessageBox.Show($"Обработанный текст: {processedText}", "Результат обработки");
        }

        private void ClearFields()
        {
            textBox1.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveText(); // Сохраняем введенный текст
            ProcessAndDisplayText(); // Обрабатываем и отображаем текст
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearFields(); // Очищаем поле ввода
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true; // Предотвращаем обработку клавиши Enter другими элементами управления
                this.SelectNextControl(this.ActiveControl, true, true, true, true); // Переходим к следующему элементу интерфейса
            }
        }
    }

    public class Logic
    {
        public string ProcessText(string text)
        {
            string[] words = text.Split(new[] { ' ', ',', '.', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);
            string new_text = "";
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length % 2 != 0)
                {
                    new_text += words[i] + " " + words[i] + " ";
                }
            }
            new_text = new_text.Replace('d', 't');
            return new_text.Trim();
        }
    }
}
